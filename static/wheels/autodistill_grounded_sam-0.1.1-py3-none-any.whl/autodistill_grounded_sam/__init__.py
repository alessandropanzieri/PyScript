from autodistill_grounded_sam.grounded_sam import GroundedSAM

__version__ = "0.1.1"
